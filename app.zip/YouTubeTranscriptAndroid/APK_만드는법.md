# APK 만드는 가장 쉬운 방법

## PC에 Android Studio가 있을 때
1. 이 폴더를 Android Studio에서 엽니다.
2. 필요한 SDK 다운로드 안내가 나오면 설치합니다.
3. 상단 메뉴 `Build`
4. `Build App Bundle(s) / APK(s)`
5. `Build APK(s)`
6. 생성된 `app-debug.apk`를 갤럭시로 보내 설치합니다.

## GitHub를 사용할 때
프로젝트 안에 `.github/workflows/build-apk.yml`을 넣어 두었습니다.
GitHub 저장소에 업로드하면 Actions에서 자동으로 디버그 APK를 만들 수 있습니다.

Actions 실행이 끝난 뒤 `YouTubeTranscript-debug-apk` 아티팩트를 받으면 됩니다.

## 갤럭시 설치
APK를 갤럭시에서 열 때 설치 차단 안내가 뜨면,
해당 브라우저/파일 앱에 대해 `이 출처의 앱 설치 허용`을 일시적으로 켠 뒤 설치합니다.
설치가 끝나면 다시 꺼도 됩니다.
