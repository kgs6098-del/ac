# YouTube 대본 추출기 v2

자막이 없는 영상도 **오디오를 직접 내려받아 Whisper로 한국어 대본/SRT를 생성**하는 Android 버전입니다.

처리 순서:

1. yt-dlp Android로 YouTube `bestaudio` 다운로드
2. FFmpegKit으로 16 kHz mono WAV 변환
3. 최초 1회 `ggml-base.bin` (~142 MB) 다운로드
4. whisper.cpp Android AAR로 기기 내부에서 한국어 음성인식
5. TXT / SRT 저장

모델은 한 번 받은 뒤 앱 내부 저장소에서 재사용합니다.
