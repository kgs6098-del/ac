# YouTube 대본 추출기 — Android 앱 소스 v1

갤럭시에서 **Colab 없이** 쓰기 위한 안드로이드 앱입니다.

## 목표 사용 흐름

### 방법 1 — 앱에서
1. 앱 실행
2. YouTube 링크 붙여넣기
3. `대본 추출 시작`
4. 자막이 있으면 바로 추출
5. 자막이 없으면 Android 13+에서 휴대폰 음성인식으로 자동 전환
6. `복사 / TXT 저장 / 공유`

### 방법 2 — YouTube 앱에서
1. YouTube 영상에서 `공유`
2. `YouTube 대본 추출기` 선택
3. 앱이 링크를 받아 자동으로 처리 시작

## 동작 방식

- 영상 정보/자막/오디오 URL 조회: Piped 공개 API의 `/streams/:videoId`
- 자막이 있으면 한국어 → 영어 → 기타 순으로 선택
- 사람이 만든 자막을 자동자막보다 우선
- 자막은 TTML을 파싱해 읽기 쉬운 텍스트로 변환
- 자막이 전혀 없으면:
  1. 가장 작은 호환 오디오 스트림을 앱 캐시에 임시 저장
  2. Android `MediaExtractor + MediaCodec`으로 PCM 디코딩
  3. Android 13(API 33)+ `RecognizerIntent.EXTRA_AUDIO_SOURCE`를 통해 음성인식기에 오디오 전달
  4. 처리 뒤 임시 오디오 삭제

## 중요한 제한

Android의 공식 `EXTRA_AUDIO_SOURCE` 기능은 **음성인식 서비스 구현에 따라 지원되지 않을 수 있습니다.**
지원하지 않는 휴대폰/음성인식 서비스에서는 자막 있는 영상만 정상 동작하고,
자막 없는 영상의 음성인식은 실패할 수 있습니다.

또한 Piped는 공개 인스턴스 기반이어서 특정 서버가 중단될 수 있습니다.
코드는 여러 공개 인스턴스를 순차적으로 시도하도록 되어 있습니다.

## APK 빌드

이 프로젝트는 Android Studio에서 그대로 열 수 있습니다.

- Android Studio: 최신 안정 버전 권장
- JDK: 17
- compileSdk: 35
- minSdk: 29
- targetSdk: 35

Android Studio에서:
`Build > Build App Bundle(s) / APK(s) > Build APK(s)`

완성된 디버그 APK:
`app/build/outputs/apk/debug/app-debug.apk`

## 개인정보

- 별도 계정/로그인/서버 키를 저장하지 않습니다.
- 영상 정보/스트림 조회 시 선택된 Piped 공개 서버와 통신합니다.
- 자막 없는 영상의 음성인식 시 휴대폰에 설정된 Android 음성인식 서비스가 사용됩니다.
- 오디오 파일은 앱 캐시에 임시 저장 후 삭제합니다.

## 저작권/이용약관

본인이 접근할 권한이 있는 공개/허용 콘텐츠의 개인적인 분석·학습 용도로 사용하고,
콘텐츠 저작권 및 관련 서비스 이용약관을 준수하세요.
