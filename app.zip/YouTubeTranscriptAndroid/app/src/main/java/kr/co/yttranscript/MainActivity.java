package kr.co.yttranscript;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements RecognitionListener {
    private static final int REQ_MIC = 2001;

    private EditText urlInput;
    private TextView status;
    private TextView titleView;
    private TextView transcriptView;
    private ProgressBar progress;
    private Button extractButton;
    private Button copyButton;
    private Button saveButton;
    private Button shareButton;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentTitle = "YouTube 대본";
    private String currentTranscript = "";
    private String currentTimestamped = "";

    private SpeechRecognizer speechRecognizer;
    private ParcelFileDescriptor speechReadFd;
    private final StringBuilder speechText = new StringBuilder();
    private File tempAudio;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        handleIncoming(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    private void buildUi() {
        int pad = dp(18);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(pad, dp(24), pad, dp(24));
        page.setBackgroundColor(Color.rgb(247, 248, 250));

        TextView h1 = text("YouTube 대본 추출기", 26, true);
        page.addView(h1);

        TextView sub = text("링크를 붙여넣거나 YouTube의 공유 메뉴에서 이 앱을 선택하세요.", 14, false);
        sub.setTextColor(Color.rgb(95, 99, 110));
        LinearLayout.LayoutParams subLp = lpMatchWrap();
        subLp.setMargins(0, dp(4), 0, dp(18));
        page.addView(sub, subLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(roundRect(Color.WHITE, dp(18)));
        page.addView(card, lpMatchWrap());

        TextView lab = text("YouTube 주소", 13, true);
        lab.setTextColor(Color.rgb(70, 73, 82));
        card.addView(lab);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextSize(15);
        urlInput.setHint("https://youtu.be/...");
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        urlInput.setBackground(roundStroke(Color.rgb(249, 250, 252), Color.rgb(220, 223, 230), dp(12)));
        LinearLayout.LayoutParams urlLp = lpMatchWrap();
        urlLp.setMargins(0, dp(8), 0, dp(12));
        card.addView(urlInput, urlLp);

        extractButton = button("대본 추출 시작", Color.rgb(49, 87, 213), Color.WHITE);
        extractButton.setOnClickListener(v -> startExtraction());
        card.addView(extractButton, lpMatch(dp(50)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pLp = lpMatch(dp(4));
        pLp.setMargins(0, dp(12), 0, 0);
        card.addView(progress, pLp);

        status = text("준비됨", 13, false);
        status.setTextColor(Color.rgb(90, 93, 103));
        LinearLayout.LayoutParams statusLp = lpMatchWrap();
        statusLp.setMargins(0, dp(10), 0, 0);
        card.addView(status, statusLp);

        titleView = text("", 18, true);
        LinearLayout.LayoutParams tLp = lpMatchWrap();
        tLp.setMargins(0, dp(20), 0, dp(8));
        page.addView(titleView, tLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(roundRect(Color.WHITE, dp(18)));
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        page.addView(scroll, scrollLp);

        transcriptView = text("대본이 여기에 표시됩니다.", 15, false);
        transcriptView.setTextColor(Color.rgb(45, 47, 53));
        transcriptView.setTextIsSelectable(true);
        transcriptView.setPadding(dp(16), dp(16), dp(16), dp(16));
        scroll.addView(transcriptView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams actionsLp = lpMatch(dp(52));
        actionsLp.setMargins(0, dp(12), 0, 0);
        page.addView(actions, actionsLp);

        copyButton = button("복사", Color.WHITE, Color.rgb(49, 87, 213));
        saveButton = button("TXT 저장", Color.WHITE, Color.rgb(49, 87, 213));
        shareButton = button("공유", Color.WHITE, Color.rgb(49, 87, 213));

        copyButton.setEnabled(false);
        saveButton.setEnabled(false);
        shareButton.setEnabled(false);

        copyButton.setOnClickListener(v -> copyTranscript());
        saveButton.setOnClickListener(v -> saveTranscript());
        shareButton.setOnClickListener(v -> shareTranscript());

        actions.addView(copyButton, weighted());
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(dp(8), 1);
        actions.addView(new View(this), gap);
        actions.addView(saveButton, weighted());
        actions.addView(new View(this), gap);
        actions.addView(shareButton, weighted());

        setContentView(page);
    }

    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) {
                String url = firstYoutubeUrl(shared);
                if (!url.isEmpty()) {
                    urlInput.setText(url);
                    startExtraction();
                }
            }
        }
    }

    private void startExtraction() {
        String raw = urlInput.getText().toString().trim();
        String id = videoId(raw);
        if (id.isEmpty()) {
            toast("YouTube 주소를 확인해 주세요.");
            return;
        }

        setBusy(true, "영상 정보를 확인하는 중...");
        clearResult();

        executor.execute(() -> {
            try {
                PipedClient.StreamInfo info = PipedClient.fetchStreamInfo(id);
                currentTitle = info.title.isEmpty() ? "YouTube 대본" : info.title;

                PipedClient.Subtitle sub = PipedClient.chooseSubtitle(info.subtitles);
                if (sub != null) {
                    uiStatus("자막 발견 · " + sub.name + (sub.autoGenerated ? " · 자동자막" : ""));
                    String xml = PipedClient.getText(sub.url, 15000);
                    SubtitleParser.Result parsed = SubtitleParser.parseTtml(xml);
                    if (parsed.plainText.isEmpty()) throw new IllegalStateException("자막 내용이 비어 있습니다.");
                    currentTranscript = parsed.plainText;
                    currentTimestamped = parsed.timestampedText;
                    runOnUiThread(() -> showResult("자막 추출 완료", currentTranscript));
                    return;
                }

                PipedClient.Audio audio = PipedClient.chooseAudio(info.audioStreams);
                if (audio == null) throw new IllegalStateException("자막과 오디오 스트림을 찾지 못했습니다.");

                if (Build.VERSION.SDK_INT < 33) {
                    throw new IllegalStateException("자막 없는 영상의 자동 음성인식은 Android 13 이상이 필요합니다.");
                }

                runOnUiThread(() -> beginNoSubtitleTranscription(audio));
            } catch (Exception e) {
                runOnUiThread(() -> fail(e));
            }
        });
    }

    private void beginNoSubtitleTranscription(PipedClient.Audio audio) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            // 권한 승인 후 사용자가 버튼을 다시 누르면 됩니다.
            setBusy(false, "마이크/음성인식 권한 승인 후 다시 '대본 추출 시작'을 눌러 주세요.");
            return;
        }

        setBusy(true, "자막 없음 · 음성인식용 오디오를 준비하는 중...");
        executor.execute(() -> {
            try {
                tempAudio = File.createTempFile("yt_audio_", ".media", getCacheDir());
                PipedClient.downloadToFile(audio.url, tempAudio, (done, total) -> {
                    if (total > 0) {
                        int pct = (int) Math.min(100, (done * 100 / total));
                        uiStatus("자막 없음 · 오디오 준비 " + pct + "%");
                    }
                });

                AudioPipeDecoder.AudioSpec spec = AudioPipeDecoder.probe(tempAudio);
                runOnUiThread(() -> startSpeechRecognition(spec));
            } catch (Exception e) {
                runOnUiThread(() -> fail(e));
            }
        });
    }

    private void startSpeechRecognition(AudioPipeDecoder.AudioSpec spec) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fail(new IllegalStateException("이 휴대폰에서 음성인식 서비스를 사용할 수 없습니다."));
            return;
        }

        try {
            destroyRecognizer();
            speechText.setLength(0);
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(this);

            ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            speechReadFd = pipe[0];
            ParcelFileDescriptor writeFd = pipe[1];

            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, speechReadFd);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, spec.channels);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, spec.sampleRate);
            i.putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION, RecognizerIntent.EXTRA_AUDIO_SOURCE);

            status.setText("음성인식 시작 · 영상 길이에 따라 시간이 걸릴 수 있습니다.");
            speechRecognizer.startListening(i);

            executor.execute(() -> {
                try (OutputStream out = new ParcelFileDescriptor.AutoCloseOutputStream(writeFd)) {
                    AudioPipeDecoder.decodeToPcm(tempAudio, out);
                } catch (Exception e) {
                    runOnUiThread(() -> fail(e));
                }
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        status.setText("음성인식 중...");
    }

    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() {}

    @Override
    public void onError(int error) {
        // 일부 서비스는 segmented session 종료 때 ERROR_NO_MATCH를 보내기도 하므로
        // 이미 텍스트가 있으면 결과를 살립니다.
        if (speechText.length() > 0) {
            finishSpeech();
            return;
        }

        String msg;
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: msg = "오디오 입력 오류"; break;
            case SpeechRecognizer.ERROR_CLIENT: msg = "음성인식 클라이언트 오류"; break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: msg = "음성인식 권한이 필요합니다"; break;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: msg = "음성인식 네트워크 오류"; break;
            case SpeechRecognizer.ERROR_NO_MATCH: msg = "음성을 인식하지 못했습니다"; break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: msg = "음성인식기가 사용 중입니다"; break;
            case SpeechRecognizer.ERROR_SERVER: msg = "음성인식 서버 오류"; break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: msg = "음성을 찾지 못했습니다"; break;
            default: msg = "음성인식 오류 (" + error + ")";
        }
        fail(new IllegalStateException(msg + "\n휴대폰의 음성인식 서비스가 파일 입력을 지원하지 않는 경우도 있습니다."));
    }

    @Override
    public void onResults(Bundle results) {
        appendSpeechResults(results);
        finishSpeech();
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r != null && !r.isEmpty()) {
            String preview = r.get(0);
            transcriptView.setText(speechText.toString() + (speechText.length() > 0 ? "\n\n" : "") + preview);
        }
    }

    @Override public void onEvent(int eventType, Bundle params) {}

    @Override
    public void onSegmentResults(Bundle segmentResults) {
        appendSpeechResults(segmentResults);
        transcriptView.setText(speechText.toString());
    }

    @Override
    public void onEndOfSegmentedSession() {
        finishSpeech();
    }

    private void appendSpeechResults(Bundle b) {
        if (b == null) return;
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r == null || r.isEmpty()) return;
        String s = r.get(0).trim();
        if (s.isEmpty()) return;

        String existing = speechText.toString();
        if (!existing.endsWith(s)) {
            if (speechText.length() > 0) speechText.append("\n\n");
            speechText.append(s);
        }
    }

    private void finishSpeech() {
        currentTranscript = speechText.toString().trim();
        currentTimestamped = "";
        if (currentTranscript.isEmpty()) {
            fail(new IllegalStateException("음성인식 결과가 비어 있습니다."));
        } else {
            showResult("음성인식 완료", currentTranscript);
        }
        destroyRecognizer();
        deleteTemp();
    }

    private void showResult(String message, String text) {
        titleView.setText(currentTitle);
        transcriptView.setText(text);
        copyButton.setEnabled(true);
        saveButton.setEnabled(true);
        shareButton.setEnabled(true);
        setBusy(false, message);
    }

    private void fail(Exception e) {
        destroyRecognizer();
        deleteTemp();
        setBusy(false, "오류 · " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        new AlertDialog.Builder(this)
                .setTitle("대본 추출 실패")
                .setMessage((e.getMessage() == null ? "알 수 없는 오류" : e.getMessage())
                        + "\n\n공개 영상이 아니거나, Piped 공개 서버/YouTube 쪽 상태에 따라 일시적으로 실패할 수 있습니다.")
                .setPositiveButton("확인", null)
                .show();
    }

    private void copyTranscript() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("YouTube 대본", currentTranscript));
        toast("대본을 복사했습니다.");
    }

    private void saveTranscript() {
        try {
            String name = sanitizeFileName(currentTitle) + ".txt";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/YouTube대본");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException("저장 위치를 만들지 못했습니다.");

            String body = currentTitle + "\n\n" + currentTranscript + "\n";
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("파일을 열지 못했습니다.");
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
            toast("다운로드/YouTube대본 폴더에 저장했습니다.");
        } catch (Exception e) {
            toast("저장 실패: " + e.getMessage());
        }
    }

    private void shareTranscript() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, currentTitle);
        i.putExtra(Intent.EXTRA_TEXT, currentTitle + "\n\n" + currentTranscript);
        startActivity(Intent.createChooser(i, "대본 공유"));
    }

    private void setBusy(boolean busy, String msg) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        extractButton.setEnabled(!busy);
        status.setText(msg);
    }

    private void uiStatus(String msg) {
        runOnUiThread(() -> status.setText(msg));
    }

    private void clearResult() {
        currentTranscript = "";
        currentTimestamped = "";
        titleView.setText("");
        transcriptView.setText("처리 중...");
        copyButton.setEnabled(false);
        saveButton.setEnabled(false);
        shareButton.setEnabled(false);
    }

    private void destroyRecognizer() {
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) {}
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (speechReadFd != null) {
            try { speechReadFd.close(); } catch (Exception ignored) {}
            speechReadFd = null;
        }
    }

    private void deleteTemp() {
        if (tempAudio != null) {
            try { tempAudio.delete(); } catch (Exception ignored) {}
            tempAudio = null;
        }
    }

    @Override
    protected void onDestroy() {
        destroyRecognizer();
        deleteTemp();
        executor.shutdownNow();
        super.onDestroy();
    }

    private String videoId(String text) {
        if (text == null) return "";
        Pattern[] patterns = new Pattern[] {
                Pattern.compile("(?:youtu\\.be/)([A-Za-z0-9_-]{11})"),
                Pattern.compile("[?&]v=([A-Za-z0-9_-]{11})"),
                Pattern.compile("(?:shorts/|embed/)([A-Za-z0-9_-]{11})"),
                Pattern.compile("^([A-Za-z0-9_-]{11})$")
        };
        for (Pattern p : patterns) {
            Matcher m = p.matcher(text);
            if (m.find()) return m.group(1);
        }
        return "";
    }

    private String firstYoutubeUrl(String text) {
        Matcher m = Pattern.compile("https?://(?:www\\.)?(?:youtube\\.com|youtu\\.be)/\\S+").matcher(text);
        if (m.find()) return m.group();
        return text;
    }

    private static String sanitizeFileName(String s) {
        String x = s == null ? "YouTube_대본" : s;
        x = x.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (x.length() > 80) x = x.substring(0, 80);
        return x.isEmpty() ? "YouTube_대본" : x;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(25, 27, 32));
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, int bg, int fg) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(bg, bg == Color.WHITE ? Color.rgb(218, 222, 230) : bg, dp(12)));
        return b;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private GradientDrawable roundStroke(int color, int stroke, int radius) {
        GradientDrawable g = roundRect(color, radius);
        g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lpMatchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams lpMatch(int h) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
