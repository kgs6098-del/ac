package kr.co.yttranscript.v2

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit_maintained.ytdlp.DownloadProgressCallback
import dev.ffmpegkit_maintained.ytdlp.YtDlp
import dev.ffmpegkit_maintained.ytdlp.YtDlpRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var titleView: TextView
    private lateinit var transcriptView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var extractButton: Button
    private lateinit var copyButton: Button
    private lateinit var saveTxtButton: Button
    private lateinit var saveSrtButton: Button

    private var currentTitle = "YouTube 대본"
    private var currentTranscript = ""
    private var currentSrt = ""

    companion object {
        private const val MODEL_URL =
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true"
        private const val MODEL_NAME = "ggml-base.bin"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        try {
            YtDlp.init(this)
            status.text = "준비됨 · 자막이 없어도 음성에서 직접 생성합니다."
        } catch (e: Exception) {
            status.text = "초기화 오류: ${e.message ?: e.javaClass.simpleName}"
        }

        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val shared = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            val url = firstYoutubeUrl(shared)
            if (url.isNotBlank()) {
                urlInput.setText(url)
                startExtraction()
            }
        }
    }

    private fun startExtraction() {
        val url = firstYoutubeUrl(urlInput.text.toString().trim())
        if (!looksLikeYoutube(url)) {
            toast("YouTube 주소를 확인해 주세요.")
            return
        }

        clearResult()
        setBusy(true, "1/4 YouTube 음성을 준비하는 중...")

        lifecycleScope.launch {
            try {
                val audioFile = withContext(Dispatchers.IO) {
                    downloadAudio(url)
                }

                setBusy(true, "2/4 음성을 WAV로 변환하는 중...")
                val wav = withContext(Dispatchers.IO) {
                    convertToWav(audioFile)
                }

                setBusy(true, "3/4 Whisper 한국어 모델을 확인하는 중...")
                val model = withContext(Dispatchers.IO) {
                    ensureModel()
                }

                setBusy(true, "4/4 음성을 분석해 자막을 만드는 중... 잠시 기다려 주세요.")
                val result = withContext(Dispatchers.Default) {
                    val loaded = Whisper.loadModel(this@MainActivity, model.absolutePath)
                    try {
                        Whisper.transcribe(
                            loaded,
                            wav.absolutePath,
                            WhisperConfig(language = "ko")
                        )
                    } finally {
                        Whisper.releaseModel(loaded)
                    }
                }

                currentTranscript = result.text.trim()
                currentSrt = buildString {
                    result.segments.forEachIndexed { index, seg ->
                        append(index + 1).append('\n')
                        append(srtTime(seg.startMs)).append(" --> ").append(srtTime(seg.endMs)).append('\n')
                        append(seg.text.trim()).append("\n\n")
                    }
                }.trim()

                if (currentTranscript.isBlank()) {
                    throw IllegalStateException("음성은 처리했지만 인식된 문장이 없습니다.")
                }

                titleView.text = currentTitle
                transcriptView.text = currentTranscript
                copyButton.isEnabled = true
                saveTxtButton.isEnabled = true
                saveSrtButton.isEnabled = true
                setBusy(false, "완료 · 음성에서 직접 대본/자막을 생성했습니다.")

                cleanupTemp()
            } catch (e: Exception) {
                cleanupTemp()
                setBusy(false, "오류 · ${friendlyError(e)}")
                transcriptView.text =
                    "처리하지 못했습니다.\n\n${friendlyError(e)}\n\n" +
                    "YouTube에서 차단한 영상이면 같은 영상의 공유 링크로 다시 시도해 보세요."
            }
        }
    }

    private fun downloadAudio(url: String): File {
        cleanupTemp()
        val dir = File(cacheDir, "ytwork").apply { mkdirs() }
        val outputTemplate = File(dir, "source.%(ext)s").absolutePath

        var lastLine = ""
        val request = YtDlpRequest(url)
            .setOutputTemplate(outputTemplate)
            .addOption("--no-playlist")
            .addOption("-f", "bestaudio[ext=m4a]/bestaudio")
            .addOption("--extractor-args", "youtube:player_client=android,web")

        val response = YtDlp.execute(
            request,
            object : DownloadProgressCallback {
                override fun onProgressUpdate(progressValue: Float, etaInSeconds: Long, line: String?) {
                    lastLine = line.orEmpty()
                    runOnUiThread {
                        val p = progressValue.coerceIn(0f, 100f).toInt()
                        status.text = "1/4 YouTube 음성 다운로드 $p%"
                    }
                }
            }
        )

        if (response.exitCode != 0) {
            throw IllegalStateException(
                "YouTube 음성을 가져오지 못했습니다." +
                    if (lastLine.isBlank()) "" else "\n$lastLine"
            )
        }

        val audio = dir.listFiles()
            ?.filter { it.isFile && it.name.startsWith("source.") }
            ?.maxByOrNull { it.length() }
            ?: throw IllegalStateException("다운로드된 음성 파일을 찾지 못했습니다.")

        return audio
    }

    private fun convertToWav(input: File): File {
        val out = File(input.parentFile, "speech.wav")
        if (out.exists()) out.delete()

        val command = "-y -i ${q(input.absolutePath)} -vn -ar 16000 -ac 1 -c:a pcm_s16le ${q(out.absolutePath)}"
        val session = FFmpegKit.execute(command)

        if (!ReturnCode.isSuccess(session.returnCode) || !out.exists() || out.length() < 1024) {
            val details = session.allLogsAsString.orEmpty().takeLast(1200)
            throw IllegalStateException("음성 변환에 실패했습니다.\n$details")
        }
        return out
    }

    private fun ensureModel(): File {
        val modelDir = File(filesDir, "models").apply { mkdirs() }
        val model = File(modelDir, MODEL_NAME)

        // 정상 base 모델은 약 142 MB. 너무 작으면 중단된 파일로 보고 다시 받습니다.
        if (model.exists() && model.length() > 100L * 1024L * 1024L) {
            return model
        }
        if (model.exists()) model.delete()

        val temp = File(modelDir, "$MODEL_NAME.part")
        if (temp.exists()) temp.delete()

        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("User-Agent", "YouTubeTranscriptAndroid/2.0")

        try {
            val code = conn.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("Whisper 모델 다운로드 실패 (HTTP $code)")
            }

            val total = conn.contentLengthLong
            var done = 0L
            conn.inputStream.use { input ->
                FileOutputStream(temp).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100L / total).toInt().coerceIn(0, 100)
                            runOnUiThread {
                                status.text = "3/4 최초 1회 Whisper 모델 다운로드 $pct% (약 142MB)"
                            }
                        }
                    }
                }
            }

            if (temp.length() < 100L * 1024L * 1024L) {
                throw IllegalStateException("Whisper 모델 파일이 완전히 다운로드되지 않았습니다.")
            }

            if (!temp.renameTo(model)) {
                temp.copyTo(model, overwrite = true)
                temp.delete()
            }
            return model
        } finally {
            conn.disconnect()
        }
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(18))
            setBackgroundColor(Color.rgb(247, 248, 250))
        }

        page.addView(text("YouTube 대본 추출기", 27, true))
        page.addView(
            text("자막이 없어도 YouTube 음성을 받아 Whisper가 직접 한국어 대본을 만듭니다.", 14, false).apply {
                setTextColor(Color.rgb(95, 99, 110))
            },
            matchWrap().apply { setMargins(0, dp(5), 0, dp(18)) }
        )

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.WHITE, dp(18))
        }
        page.addView(card, matchWrap())

        card.addView(text("YouTube 주소", 13, true))

        urlInput = EditText(this).apply {
            hint = "https://youtu.be/..."
            textSize = 15f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = strokeRounded(
                Color.rgb(249, 250, 252),
                Color.rgb(220, 223, 230),
                dp(12)
            )
        }
        card.addView(urlInput, matchWrap().apply { setMargins(0, dp(8), 0, dp(12)) })

        extractButton = button("음성에서 대본 생성", Color.rgb(49, 87, 213), Color.WHITE).apply {
            setOnClickListener { startExtraction() }
        }
        card.addView(extractButton, matchHeight(54))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        card.addView(progress, matchHeight(dp(4)).apply { setMargins(0, dp(12), 0, 0) })

        status = text("초기화 중...", 13, false).apply {
            setTextColor(Color.rgb(75, 79, 90))
        }
        card.addView(status, matchWrap().apply { setMargins(0, dp(10), 0, 0) })

        titleView = text("", 18, true)
        page.addView(titleView, matchWrap().apply { setMargins(0, dp(18), 0, dp(8)) })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = rounded(Color.WHITE, dp(18))
        }
        page.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        transcriptView = text("대본이 여기에 표시됩니다.", 15, false).apply {
            setTextColor(Color.rgb(45, 47, 53))
            setTextIsSelectable(true)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        scroll.addView(transcriptView)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        page.addView(actions, matchHeight(52).apply { setMargins(0, dp(12), 0, 0) })

        copyButton = button("복사", Color.WHITE, Color.rgb(49, 87, 213)).apply {
            isEnabled = false
            setOnClickListener { copyTranscript() }
        }
        saveTxtButton = button("TXT 저장", Color.WHITE, Color.rgb(49, 87, 213)).apply {
            isEnabled = false
            setOnClickListener { saveToDownloads("txt", currentTranscript) }
        }
        saveSrtButton = button("SRT 저장", Color.WHITE, Color.rgb(49, 87, 213)).apply {
            isEnabled = false
            setOnClickListener { saveToDownloads("srt", currentSrt) }
        }

        actions.addView(copyButton, weight())
        actions.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(saveTxtButton, weight())
        actions.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(saveSrtButton, weight())

        setContentView(page)
    }

    private fun clearResult() {
        currentTranscript = ""
        currentSrt = ""
        titleView.text = ""
        transcriptView.text = "처리 중..."
        copyButton.isEnabled = false
        saveTxtButton.isEnabled = false
        saveSrtButton.isEnabled = false
    }

    private fun setBusy(busy: Boolean, message: String) {
        extractButton.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun copyTranscript() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("YouTube 대본", currentTranscript))
        toast("대본을 복사했습니다.")
    }

    private fun saveToDownloads(ext: String, body: String) {
        if (body.isBlank()) return
        try {
            val fileName = sanitize(currentTitle) + "." + ext
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(
                    MediaStore.Downloads.MIME_TYPE,
                    if (ext == "srt") "application/x-subrip" else "text/plain"
                )
                put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/YouTube대본"
                )
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("저장 위치를 만들지 못했습니다.")
            contentResolver.openOutputStream(uri).use { output ->
                requireNotNull(output) { "파일을 열지 못했습니다." }
                output.write(body.toByteArray(StandardCharsets.UTF_8))
            }
            toast("다운로드/YouTube대본에 저장했습니다.")
        } catch (e: Exception) {
            toast("저장 실패: ${e.message}")
        }
    }

    private fun cleanupTemp() {
        try {
            File(cacheDir, "ytwork").deleteRecursively()
        } catch (_: Exception) {
        }
    }

    private fun firstYoutubeUrl(text: String): String {
        val m = Pattern.compile(
            "https?://(?:www\\.)?(?:youtube\\.com|youtu\\.be)/[^\\s]+",
            Pattern.CASE_INSENSITIVE
        ).matcher(text)
        return if (m.find()) m.group() ?: "" else text.trim()
    }

    private fun looksLikeYoutube(url: String): Boolean {
        val u = url.lowercase(Locale.US)
        return u.contains("youtube.com/") || u.contains("youtu.be/")
    }

    private fun friendlyError(e: Exception): String {
        val raw = (e.message ?: e.javaClass.simpleName).replace("\\n", "\n")
        return when {
            raw.contains("Sign in to confirm", ignoreCase = true) ->
                "YouTube가 자동 요청을 차단했습니다. 휴대폰 네트워크를 바꿔 다시 시도해 주세요."
            raw.contains("HTTP Error 403", ignoreCase = true) ->
                "YouTube가 이 영상의 음성 다운로드를 차단했습니다."
            else -> raw.take(1800)
        }
    }

    private fun srtTime(ms: Long): String {
        val total = ms.coerceAtLeast(0)
        val h = total / 3_600_000
        val m = (total % 3_600_000) / 60_000
        val s = (total % 60_000) / 1_000
        val milli = total % 1_000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    private fun q(path: String): String = "\"" + path.replace("\"", "\\\"") + "\""

    private fun sanitize(value: String): String {
        var x = value.ifBlank { "YouTube_대본" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
        if (x.length > 80) x = x.substring(0, 80)
        return x.ifBlank { "YouTube_대본" }
    }

    private fun text(value: String, sp: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = sp.toFloat()
            setTextColor(Color.rgb(25, 27, 32))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(label: String, bg: Int, fg: Int): Button =
        Button(this).apply {
            text = label
            setTextColor(fg)
            textSize = 14f
            isAllCaps = false
            gravity = Gravity.CENTER
            background = strokeRounded(
                bg,
                if (bg == Color.WHITE) Color.rgb(218, 222, 230) else bg,
                dp(12)
            )
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun strokeRounded(color: Int, stroke: Int, radius: Int): GradientDrawable =
        rounded(color, radius).apply { setStroke(dp(1), stroke) }

    private fun matchWrap() =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

    private fun matchHeight(height: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)

    private fun weight() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
