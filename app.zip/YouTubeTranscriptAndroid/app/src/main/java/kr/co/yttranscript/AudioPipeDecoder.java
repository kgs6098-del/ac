package kr.co.yttranscript;

import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.File;
import java.io.OutputStream;
import java.nio.ByteBuffer;

public final class AudioPipeDecoder {
    public static final class AudioSpec {
        public int sampleRate = 16000;
        public int channels = 1;
        public String mime = "";
    }

    private AudioPipeDecoder() {}

    public static AudioSpec probe(File file) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(file.getAbsolutePath());
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    AudioSpec s = new AudioSpec();
                    s.mime = mime;
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        s.sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        s.channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                    return s;
                }
            }
            throw new IllegalStateException("오디오 트랙을 찾지 못했습니다.");
        } finally {
            ex.release();
        }
    }

    public static void decodeToPcm(File file, OutputStream pipeOut) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        try {
            extractor.setDataSource(file.getAbsolutePath());

            int track = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    track = i;
                    format = f;
                    break;
                }
            }
            if (track < 0 || format == null) throw new IllegalStateException("오디오 트랙이 없습니다.");

            extractor.selectTrack(track);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) throw new IllegalStateException("오디오 형식을 확인할 수 없습니다.");

            // 가능한 경우 16-bit PCM 출력을 요청합니다.
            try {
                format.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            } catch (Exception ignored) {}

            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(format, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;

            while (!outputDone) {
                if (!inputDone) {
                    int inIndex = codec.dequeueInputBuffer(10_000);
                    if (inIndex >= 0) {
                        ByteBuffer in = codec.getInputBuffer(inIndex);
                        if (in != null) {
                            in.clear();
                            int size = extractor.readSampleData(in, 0);
                            if (size < 0) {
                                codec.queueInputBuffer(
                                        inIndex, 0, 0, 0,
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                long time = extractor.getSampleTime();
                                codec.queueInputBuffer(inIndex, 0, size, time, 0);
                                extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = codec.dequeueOutputBuffer(info, 10_000);
                if (outIndex >= 0) {
                    ByteBuffer out = codec.getOutputBuffer(outIndex);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        byte[] bytes = new byte[info.size];
                        out.get(bytes);
                        pipeOut.write(bytes);
                    }
                    codec.releaseOutputBuffer(outIndex, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true;
                    }
                }
            }
            pipeOut.flush();
        } finally {
            try { pipeOut.close(); } catch (Exception ignored) {}
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                codec.release();
            }
            extractor.release();
        }
    }
}
