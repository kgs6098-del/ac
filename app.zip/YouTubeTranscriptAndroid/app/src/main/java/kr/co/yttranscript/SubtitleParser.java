package kr.co.yttranscript;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public final class SubtitleParser {
    public static final class Result {
        public String plainText = "";
        public String timestampedText = "";
        public int count = 0;
    }

    private SubtitleParser() {}

    public static Result parseTtml(String xml) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(new StringReader(xml));

        List<String> plain = new ArrayList<>();
        List<String> timed = new ArrayList<>();

        boolean inP = false;
        String begin = "";
        StringBuilder current = new StringBuilder();

        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                if ("p".equalsIgnoreCase(parser.getName())) {
                    inP = true;
                    current.setLength(0);
                    begin = attr(parser, "begin");
                } else if (inP && ("br".equalsIgnoreCase(parser.getName()))) {
                    current.append(' ');
                }
            } else if (event == XmlPullParser.TEXT && inP) {
                current.append(parser.getText()).append(' ');
            } else if (event == XmlPullParser.END_TAG
                    && "p".equalsIgnoreCase(parser.getName())
                    && inP) {
                inP = false;
                String text = clean(current.toString());
                if (!text.isEmpty()) {
                    if (plain.isEmpty() || !plain.get(plain.size() - 1).equals(text)) {
                        plain.add(text);
                        timed.add(formatStamp(begin) + text);
                    }
                }
            }
            event = parser.next();
        }

        Result r = new Result();
        r.plainText = String.join("\n\n", plain);
        r.timestampedText = String.join("\n", timed);
        r.count = plain.size();
        return r;
    }

    private static String attr(XmlPullParser p, String name) {
        for (int i = 0; i < p.getAttributeCount(); i++) {
            if (name.equalsIgnoreCase(p.getAttributeName(i))) {
                return p.getAttributeValue(i);
            }
        }
        return "";
    }

    private static String clean(String s) {
        return s.replaceAll("\\s+", " ").trim();
    }

    private static String formatStamp(String begin) {
        if (begin == null || begin.isEmpty()) return "";
        try {
            double sec;
            if (begin.endsWith("s")) {
                sec = Double.parseDouble(begin.substring(0, begin.length() - 1));
            } else if (begin.contains(":")) {
                String[] p = begin.split(":");
                sec = 0;
                for (String part : p) sec = sec * 60 + Double.parseDouble(part);
            } else {
                return "";
            }
            long whole = (long) sec;
            long h = whole / 3600;
            long m = (whole % 3600) / 60;
            long s = whole % 60;
            if (h > 0) return String.format("[%02d:%02d:%02d] ", h, m, s);
            return String.format("[%02d:%02d] ", m, s);
        } catch (Exception ignored) {
            return "";
        }
    }
}
