plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "kr.co.yttranscript.v2"
    compileSdk = 35

    defaultConfig {
        applicationId = "kr.co.yttranscript.v2"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        jniLibs {
            // whisper-android와 ffmpeg-kit이 같은 libc++_shared.so를 포함하므로
            // APK 병합 시 하나만 선택합니다.
            pickFirsts += setOf("lib/arm64-v8a/libc++_shared.so")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    implementation("dev.ffmpegkit-maintained:yt-dlp-android:2.0.2")
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")
}
